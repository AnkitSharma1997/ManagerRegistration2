package com.cognizant.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cognizant.service.ManagerServiceImpl;

public class ManagerTesting {

	 private ManagerServiceImpl managerService = null;
	@Before
	public void setUp() throws Exception {
		managerService = new ManagerServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		managerService=null;
	}

//	@Test
//	public void testManagerRegister() {
//		try{
//			
//		}
//		catch (Exception e) {
//			
//		}
//	}

	@Test
	public void testCheckCredentilas() {
		try{
			String manager_id = "456";
			String manager_password = "kira";
			boolean expected = true;
			boolean actual = managerService.checkCredentilas(manager_id, manager_password);
			
			assertEquals(expected,actual);
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
